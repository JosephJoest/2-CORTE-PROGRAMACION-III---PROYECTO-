﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity
{
    public class EntidadFactura
    {

        public int reciboN { set; get; }

        public string nombreProducto { set; get; }

        public int precio { set; get; }

        public int cantidad { set; get; }

        public string cliente { set; get; } 

        public string descripcion { set; get; }

        public int total { set; get; }

        public EntidadFactura()
        {
        }

        public EntidadFactura(int reciboN,string nombreProducto, int precio, int cantidad, string cliente, string descripcion, int total)
        {
            this.reciboN = reciboN;
            this.nombreProducto= nombreProducto;
            this.precio = precio;
            this.cantidad= cantidad;
            this.cliente = cliente;
            this.descripcion = descripcion;
            this.total = total;
        }


        public override string ToString()
        {
            return $"Recibo #{reciboN}\nNombre del producto: {nombreProducto}\nPrecio: {precio}\nCantidad: {cantidad}\nCliente {cliente}\nDescripcion del producto: {descripcion}\nTotal a pagar: {total}";
        }

    }
}
