﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entity;
using Service;

namespace InterfazGraficaFacturacion
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            Limpiar();

            tbId.Focus();
        }

        public void Limpiar()
        {
            tbId.Text = string.Empty;
            tbNombreProducto.Text = string.Empty;
            tbPrecio.Text = string.Empty;
            tbCantidad.Text = string.Empty;
            tbCliente.Text = string.Empty;

        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            Guardar();
        }

        public void Guardar()
        {
            var factura = new EntidadFactura();

            factura.reciboN = int.Parse(tbId.Text);
            factura.nombreProducto = tbNombreProducto.Text;
            factura.precio = int.Parse(tbPrecio.Text);
            factura.cantidad = int.Parse(tbPrecio.Text);
            factura.cliente = tbPrecio.Text;
            factura.descripcion = tbPrecio.Text;

            tbId.Focus();
        }

        private void gridTabla_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }

        private void lstProductos_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }
    }
}
