﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Service;

namespace ProyectoFacturacionElectronica
{
    internal class Principal
    {
        static void Main(string[] args)
        {
            Logica servicio = new Logica();
            int op;

            do
            {
                string menu = "------FACTURACION-------\n" +
                    "1. Crear factura\n" +
                    "2. Buscar un registro\n" +
                    "3. Eliminar un registro\n" +
                    "4. Mostrar ultimo registro\n" +
                    "5. Mostrar el historial de registros\n" +
                    "6. Eliminar todos los datos de la factura\n" +
                    "7. Salir\n";

                Console.WriteLine(menu);

                op = int.Parse(Console.ReadLine());

                switch (op)
                {
                    case 1:
                        servicio.crearFactura();
                        Console.Clear();
                        break;
                    case 2:
                        servicio.buscarRegistro();
                        Console.ReadKey();
                        Console.Clear();
                        break;
                    case 3:
                        servicio.eliminarRegistro();
                        Console.WriteLine("Registro eliminado");
                        Console.ReadKey();
                        Console.Clear();
                        break;
                    case 4:
                        servicio.mostrarUltimoRegistro();
                        Console.ReadKey();
                        Console.Clear();
                        break;
                    case 5:
                        servicio.historialDeFacturas();
                        Console.ReadKey();
                        Console.Clear();
                        break;
                    case 6:
                        servicio.eliminarAll();
                        Console.ReadKey();
                        Console.Clear();    
                        break;
                    case 7:
                        return;
                    default: 
                        Console.WriteLine("Opcion incorrecta");
                        Console.ReadKey();
                        Console.Clear();
                        break;
                }

            } while (op >= 1 && op <= 8);


        }
    }
}
