﻿using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entity;

namespace Service
{
    public class Logica
    {

        EntidadFactura enti = new EntidadFactura();
        int cont = 1;
        
        public void crearFactura()
        {
            //Para llevar el incremento del numero de facturas
            enti.reciboN = cont;
            cont++;

            Console.Write("Nombre del producto: ");
            enti.nombreProducto = Console.ReadLine();

            Console.Write("Precio: ");
            enti.precio = int.Parse(Console.ReadLine());

            Console.Write("Cantidad: ");
            enti.cantidad = int.Parse(Console.ReadLine()); 

            Console.Write("cliente: ");
            enti.cliente = Console.ReadLine();

            Console.Write("Descripcion: ");
            enti.descripcion = Console.ReadLine();

            //Calcular el total
            int total;
            total = enti.precio * enti.cantidad;
            enti.total = total;

            //Creacion de archivo
            string archivo = "Factura.txt";

            //Para que no sobreescriba el archivo
            //StreamWriter sw = new StreamWriter(nombreArchivo, true);

            //Para sobreescribir el archivo
            //StreamWriter sw = File.CreateText(nombre);

            StreamWriter sw = new StreamWriter(archivo, true);

            sw.WriteLine(enti.ToString());

            sw.Close();

        }


        public void buscarRegistro()
        {
            // Ruta del archivo
            string rutaArchivo = "Factura.txt";

            // Nombre del producto a buscar (ingresado por consola)
            Console.Write("Ingrese el nombre del producto: ");
            string nombreProducto = Console.ReadLine();
            //Console.Clear();

            // Abrir el archivo para leer
            using (StreamReader sr = new StreamReader(rutaArchivo))
            {
                string linea;
                bool encontrada = false;
                int controlador = 1;

                // Recorrer el archivo línea por línea
                while ((linea = sr.ReadLine()) != null)
                {
                    // Verificar si la línea corresponde al nombre del producto
                    if (linea.StartsWith("Nombre del producto: " + nombreProducto))
                    {
                        encontrada = true;

                        controlador++;
                        if (controlador == 1)
                        {
                            Console.WriteLine(linea); // Imprimir línea con el nombre del producto
                        }

                    }

                    // Si se encuentra el producto, imprimir las líneas hasta llegar al "Total a pagar"
                    if (encontrada)
                    {
                        Console.WriteLine(linea); // Imprimir línea actual

                        // Verificar si se llegó al final del recibo
                        if (linea.StartsWith("Total a pagar:"))
                        {
                            break; // Salir del bucle
                        }
                    }
                }
            }

        }

        public void eliminarRegistro()
        {

            // Ruta del archivo
            string rutaArchivo = "Factura.txt";

            // Nombre del producto a eliminar (ingresado por consola)
            Console.Write("Ingrese el nombre del producto a eliminar: ");
            string nombreProducto = Console.ReadLine();

            // Ruta del archivo temporal
            string rutaTemporal = "ruta_temporal.txt";

            // Abrir el archivo original para leer
            using (StreamReader sr = new StreamReader(rutaArchivo))
            {
                // Abrir el archivo temporal para escribir
                using (StreamWriter sw = new StreamWriter(rutaTemporal))
                {
                    string linea;
                    bool eliminar = false;

                    // Recorrer el archivo línea por línea
                    while ((linea = sr.ReadLine()) != null)
                    {
                        // Verificar si la línea corresponde al nombre del producto
                        if (linea.StartsWith("Nombre del producto: " + nombreProducto))
                        {
                            eliminar = true;
                            continue; // Omitir las líneas del registro a eliminar
                        }

                        // Si no se debe eliminar, escribir la línea en el archivo temporal
                        if (!eliminar)
                        {
                            sw.WriteLine(linea);
                        }

                        // Verificar si se llegó al final del recibo
                        if (linea.StartsWith("Total a pagar:"))
                        {
                            eliminar = false; // Reiniciar la bandera
                        }
                    }
                }
            }

            // Reemplazar el archivo original con el archivo temporal
            File.Replace(rutaTemporal, rutaArchivo, null);

            Console.WriteLine("El registro ha sido eliminado.");
        }

        public void mostrarUltimoRegistro()
        {
            string archivo = "Factura.txt";

            string[] lineas = File.ReadAllLines(archivo);

            int cant = lineas.Length;

            string mostrar = lineas.ElementAt(cant - 7) + "\n" + lineas.ElementAt(cant - 6) + "\n" + lineas.ElementAt(cant - 5) + "\n" + lineas.ElementAt(cant - 4) + "\n" + lineas.ElementAt(cant - 3) + "\n" + lineas.ElementAt(cant - 2) + "\n" + lineas.ElementAt(cant - 1);

            Console.WriteLine(mostrar);

        }

        public void historialDeFacturas()
        {
            string archivo = "Factura.txt";

            StreamReader sr = new StreamReader(archivo);

            string lectura = sr.ReadToEnd();

            sr.Close();

            Console.WriteLine(lectura);


        }



        public void eliminarAll()
        {

            string archivo = "Factura.txt";

            //Con la funcion Empty elimina todo lo asociado en el archivo

            File.WriteAllText(archivo, string.Empty);

            Console.WriteLine("Historial de registros eliminados");

        }



    }
}
